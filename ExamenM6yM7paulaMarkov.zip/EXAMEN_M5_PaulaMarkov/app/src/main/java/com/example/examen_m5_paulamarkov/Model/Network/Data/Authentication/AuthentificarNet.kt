package com.example.examen_m5_paulamarkov.Model.Network.Data.Authentication

data class AuthentificarNet (

    var email : String,
    var password : String

)