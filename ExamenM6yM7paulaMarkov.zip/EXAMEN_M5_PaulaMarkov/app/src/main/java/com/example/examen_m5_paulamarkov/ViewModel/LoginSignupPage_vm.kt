package com.example.examen_m5_paulamarkov.ViewModel

class LoginSignupPage_vm {
}