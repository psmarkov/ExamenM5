package com.example.examen_m5_paulamarkov.Model

object Token {


    // Objeto Token para llevarlo a todas partes
    var objKen : String = " "



}