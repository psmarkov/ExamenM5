package com.example.examen_m5_paulamarkov.Model.Local

data class Usuario(

    val id: Long,
    val nombre: String,
    val apellido:String,
    val email:String,
    val contrasena:String

)