package com.example.examen_m5_paulamarkov.Model.Network.Data.Authentication

data class TokenNet (

    var accessToken : String

)