package com.example.examen_m5_paulamarkov.Model.Local

data class TransaccionItem(

    val ti_nombre: String,
    val ti_fecha:String,
    val ti_cantidad:String,
    val ti_foto:Int
)
